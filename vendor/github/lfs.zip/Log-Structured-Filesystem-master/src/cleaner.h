#ifndef CLEANER_H
#define CLEANER_H

int clean_cost(int segno, char *ssbuf);
void lfs_clean();

#endif
